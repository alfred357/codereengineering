package ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import model.HasCategory;
import model.Item;

/**
 * Owns every System.out / Scanner call. One Scanner for the whole app
 * (the original created a new one in 7 different methods, none closed).
 * We intentionally do not close it, since it wraps System.in.
 */
public class ConsoleView {
    private final Scanner scanner = new Scanner(System.in);

    public void print(String message) {
        System.out.println(message);
    }

    public void printBlank() {
        System.out.println("\n\n");
    }

    /** Safe integer read: re-prompts instead of crashing on bad input. */
    public int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                int value = scanner.nextInt();
                scanner.nextLine();
                return value;
            } catch (InputMismatchException e) {
                scanner.nextLine();
                System.out.println("Please enter a whole number.");
            }
        }
    }

    public double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double value = scanner.nextDouble();
                scanner.nextLine();
                return value;
            } catch (InputMismatchException e) {
                scanner.nextLine();
                System.out.println("Please enter a valid number.");
            }
        }
    }

    public String readLine(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine();
    }

    /** The single source of truth for the item table (was duplicated 3x). */
    public <T extends Item & HasCategory> void printItemTable(List<T> items) {
        System.out.printf("%-3s | %-30s | %-9s | %-10s |%n", "No", "Item's Name", "Price", "Category");
        for (int i = 0; i < items.size(); i++) {
            T item = items.get(i);
            System.out.printf("%-3d | %-30s | $%-9.2f | %-10s |%n",
                    i + 1, item.getName(), item.getPrice(), item.category().label());
        }
    }
}
