package app;

import customer.Customer;
import model.Item;
import ui.ConsoleView;

public class CustomerController {
    private static final int BROWSE = 1;
    private static final int VIEW_BASKET = 2;
    private static final int LOGOUT = 3;
    private static final int EXIT = 4;

    private final ConsoleView view;
    private final Customer customer;
    private final BrowseController browseController;

    public CustomerController(ConsoleView view, Customer customer, BrowseController browseController) {
        this.view = view;
        this.customer = customer;
        this.browseController = browseController;
    }

    /** Returns when the customer logs out; the top-level loop re-prompts login. */
    public void run() {
        while (true) {
            view.printBlank();
            view.print("Welcome to Uniqqler, " + customer.getName());
            view.print("1. Browse Items");
            view.print("2. View basket");
            view.print("3. Logout");
            view.print("4. Exit");

            int choice = view.readInt(">> ");
            switch (choice) {
                case BROWSE:
                    browseController.browse();
                    break;
                case VIEW_BASKET:
                    viewBasket();
                    break;
                case LOGOUT:
                    return;
                case EXIT:
                    view.print("Exiting...");
                    System.exit(0);
                    break;
                default:
                    view.print("Invalid option");
                    break;
            }
        }
    }

    private void viewBasket() {
        if (customer.isBasketEmpty()) {        // Hide Delegate
            view.print("Basket is empty");
            return;
        }
        view.print("Items in basket:");
        for (Item item : customer.getBasketItems()) {
            view.print("- " + item.getName() + " | $" + item.getPrice());
        }
    }
}
