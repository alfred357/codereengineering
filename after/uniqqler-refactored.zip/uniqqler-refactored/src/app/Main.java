package app;

import customer.Customer;
import model.Category;
import model.Shirt;
import model.Store;
import ui.ConsoleView;

public class Main {
    private final ConsoleView view = new ConsoleView();
    private final Store<Shirt> shirtStore = new Store<>();
    private final Customer customer = new Customer("Guest");
    private final CustomerController customerController;
    private final AdminController adminController;

    public Main() {
        seedDefaultItems();
        BrowseController browseController = new BrowseController(view, shirtStore, customer);
        customerController = new CustomerController(view, customer, browseController);
        adminController = new AdminController(view, shirtStore, browseController);
    }

    /** Single top-level loop replaces the recursive login()->menu()->login() chain. */
    public void run() {
        while (true) {
            switch (login()) {
                case CUSTOMER:
                    customerController.run();
                    break;
                case ADMIN:
                    adminController.run();
                    break;
                default:
                    view.print("Unknown credential. Try 'admin' or 'customer'.");
                    break;
            }
        }
    }

    private Role login() {
        String credential = view.readLine("Enter credential (admin / customer): ").trim().toLowerCase();
        switch (credential) {
            case "admin":
                return Role.ADMIN;
            case "customer":
                return Role.CUSTOMER;
            default:
                return Role.UNKNOWN;
        }
    }

    private void seedDefaultItems() {
        shirtStore.addItem(Shirt.of(Category.LONG,  "Blue Long Sleeve Shirt",   25.0, "blue"));
        shirtStore.addItem(Shirt.of(Category.LONG,  "Green Long Sleeve Shirt",  30.0, "green"));
        shirtStore.addItem(Shirt.of(Category.LONG,  "Black Long Sleeve Shirt",  28.0, "black"));
        shirtStore.addItem(Shirt.of(Category.SHORT, "Red Short Sleeve Shirt",   20.0, "red"));
        shirtStore.addItem(Shirt.of(Category.SHORT, "White Short Sleeve Shirt", 22.0, "white"));
        shirtStore.addItem(Shirt.of(Category.SHORT, "Yellow Short Sleeve Shirt",18.0, "yellow"));
        shirtStore.addItem(Shirt.of(Category.LONG,  "Gray Long Sleeve Shirt",   27.0, "gray"));
        shirtStore.addItem(Shirt.of(Category.SHORT, "Blue Short Sleeve Shirt",  19.0, "blue"));
    }

    public static void main(String[] args) {
        new Main().run();
    }
}
