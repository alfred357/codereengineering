package app;

public enum Role {
    CUSTOMER, ADMIN, UNKNOWN
}
