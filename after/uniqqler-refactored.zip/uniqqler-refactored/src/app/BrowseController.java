package app;

import java.util.List;

import customer.Customer;
import model.Category;
import model.Shirt;
import model.Store;
import ui.ConsoleView;

/** The "Browse Items" sub-menu, extracted out of the old Main.browseItems(). */
public class BrowseController {
    private static final int FILTER_CATEGORY = 1;
    private static final int FILTER_COLOR = 2;
    private static final int SORT_NAME = 3;
    private static final int SORT_PRICE_ASC = 4;
    private static final int SORT_PRICE_DESC = 5;
    private static final int RESET = 6;
    private static final int SHOW_AND_ADD = 7;
    private static final int BACK = 0;

    private final ConsoleView view;
    private final Store<Shirt> store;
    private final Customer customer;

    public BrowseController(ConsoleView view, Store<Shirt> store, Customer customer) {
        this.view = view;
        this.store = store;
        this.customer = customer;
    }

    public void browse() {
        List<Shirt> currentList = store.getItems();
        while (true) {
            printMenu();
            int choice = view.readInt(">> ");
            switch (choice) {
                case FILTER_CATEGORY:
                    currentList = filterByCategory();
                    break;
                case FILTER_COLOR:
                    currentList = filterByColor();
                    break;
                case SORT_NAME:
                    currentList = store.sortByName();
                    break;
                case SORT_PRICE_ASC:
                    currentList = store.sortByPriceAsc();
                    break;
                case SORT_PRICE_DESC:
                    currentList = store.sortByPriceDesc();
                    break;
                case RESET:
                    currentList = store.getItems();
                    break;
                case SHOW_AND_ADD:
                    showItemsAndAddToBasket(currentList);
                    break;
                case BACK:
                    return;
                default:
                    view.print("Invalid option");
                    break;
            }
        }
    }

    private void printMenu() {
        view.printBlank();
        view.print("Browse Items");
        view.print("1. Filter by category");
        view.print("2. Filter by color");
        view.print("3. Sort by name");
        view.print("4. Sort by price ascending");
        view.print("5. Sort by price descending");
        view.print("6. Reset filter");
        view.print("7. Show items / Add to basket");
        view.print("0. Back to menu");
    }

    private List<Shirt> filterByCategory() {
        view.print("Available categories: ");
        for (Category category : store.getAvailableCategories()) {
            view.print("- " + category.label());
        }
        String input = view.readLine("Enter category: ").trim();
        try {
            return store.filterByCategory(Category.fromLabel(input));
        } catch (IllegalArgumentException e) {
            view.print("Unknown category. Keeping current list.");
            return store.getItems();
        }
    }

    private List<Shirt> filterByColor() {
        view.print("Available colors: ");
        for (String color : store.getAvailableColors()) {
            view.print("- " + color);
        }
        String color = view.readLine("Enter color: ");
        return store.filterByColor(color);
    }

    private void showItemsAndAddToBasket(List<Shirt> currentList) {
        if (currentList.isEmpty()) {
            view.print("No Item in Store");
            return;
        }
        view.printItemTable(currentList);
        int choice = view.readInt("Choose an Item Number to Add to Basket (0 to cancel): ");
        if (choice > 0 && choice <= currentList.size()) {
            Shirt chosen = currentList.get(choice - 1);
            customer.addToBasket(chosen);   // Hide Delegate
            view.print(chosen.getName() + " added to basket!");
        } else if (choice != 0) {
            view.print("Input a valid option");
        }
    }
}
