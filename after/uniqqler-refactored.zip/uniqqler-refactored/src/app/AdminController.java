package app;

import java.util.List;

import model.Category;
import model.Shirt;
import model.Store;
import ui.ConsoleView;

public class AdminController {
    private static final int BROWSE = 1;
    private static final int ADD_ITEM = 2;
    private static final int UPDATE_PRICE = 3;
    private static final int DELETE_ITEM = 4;
    private static final int LOGOUT = 5;
    private static final int EXIT = 6;

    private final ConsoleView view;
    private final Store<Shirt> store;
    private final BrowseController browseController;

    public AdminController(ConsoleView view, Store<Shirt> store, BrowseController browseController) {
        this.view = view;
        this.store = store;
        this.browseController = browseController;
    }

    public void run() {
        while (true) {
            printMenu();
            int choice = view.readInt(">> ");
            switch (choice) {
                case BROWSE:
                    browseController.browse();
                    break;
                case ADD_ITEM:
                    addItem();
                    break;
                case UPDATE_PRICE:
                    updatePrice();   // renamed from UpdatePriceInStore
                    break;
                case DELETE_ITEM:
                    deleteItem();
                    break;
                case LOGOUT:
                    return;
                case EXIT:
                    view.print("Exiting...");
                    System.exit(0);
                    break;
                default:
                    view.print("Invalid option");
                    break;
            }
        }
    }

    private void printMenu() {
        view.printBlank();
        view.print("Welcome to Uniqqler Admin page");
        view.print("1. Browse Items");
        view.print("2. Add Item to Store");
        view.print("3. Update Item's price in Store");
        view.print("4. Delete Item from Store");
        view.print("5. Logout");
        view.print("6. Exit");
    }

    private void addItem() {
        String categoryInput = view.readLine("Enter category (long, short): ").trim();
        Category category;
        try {
            category = Category.fromLabel(categoryInput);
        } catch (IllegalArgumentException e) {
            view.print("Unknown category. Item was not added.");
            return;
        }
        String name = view.readLine("Enter Item's Name (format: color category shirt): ");
        String color = view.readLine("Enter item's color: ");
        double price = view.readDouble("Enter item's price: ");

        store.addItem(Shirt.of(category, name, price, color));
        view.print("Item added to Store!");
        view.readLine("Press enter to continue...");
    }

    private void updatePrice() {
        List<Shirt> currentList = store.getItems();
        view.printItemTable(currentList);

        int choice = view.readInt("Choose an item to Update Price (index): ");
        if (choice <= 0 || choice > currentList.size()) {
            view.print("Input a valid option");
            return;
        }
        double newPrice = view.readDouble("Input item's new price: ");
        currentList.get(choice - 1).setPrice(newPrice);

        view.print("Price is updated");
        view.readLine("Press enter to continue...");
    }

    private void deleteItem() {
        List<Shirt> currentList = store.getItems();
        view.printItemTable(currentList);

        int choice = view.readInt("Choose an item to remove (index): ");
        if (choice <= 0 || choice > currentList.size()) {
            view.print("Input a valid option");
            return;
        }
        store.removeItem(currentList.get(choice - 1));

        view.print("Item is deleted");
        view.readLine("Press enter to continue...");
    }
}
