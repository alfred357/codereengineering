package model;

/** Anything that belongs to a Category. (Renamed: type names use PascalCase.) */
public interface HasCategory {
    Category category();
}
