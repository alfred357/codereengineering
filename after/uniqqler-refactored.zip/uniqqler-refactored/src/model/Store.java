package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** A reusable, generic container of items. UI concerns live elsewhere. */
public class Store<T extends Item & HasCategory> {
    private final List<T> items = new ArrayList<>();

    public void addItem(T item) {
        items.add(item);
    }

    public void removeItem(T item) {
        items.remove(item);
    }

    /** Encapsulate Collection: callers get a read-only view, not the live list. */
    public List<T> getItems() {
        return Collections.unmodifiableList(items);
    }

    /** Moved here from Main (was Feature Envy). */
    public List<Category> getAvailableCategories() {
        Set<Category> result = new LinkedHashSet<>();
        for (T item : items) {
            result.add(item.category());
        }
        return new ArrayList<>(result);
    }

    /** Moved here from Main (was Feature Envy). */
    public List<String> getAvailableColors() {
        Set<String> result = new LinkedHashSet<>();
        for (T item : items) {
            result.add(item.getColor());
        }
        return new ArrayList<>(result);
    }

    public List<T> filterByCategory(Category category) {
        List<T> out = new ArrayList<>();
        for (T item : items) {
            if (item.category() == category) {
                out.add(item);
            }
        }
        return out;
    }

    public List<T> filterByColor(String color) {
        List<T> out = new ArrayList<>();
        for (T item : items) {
            if (item.getColor().equalsIgnoreCase(color)) {
                out.add(item);
            }
        }
        return out;
    }

    public List<T> sortByName() {
        List<T> out = new ArrayList<>(items);
        out.sort(Comparator.comparing(Item::getName));
        return out;
    }

    public List<T> sortByPriceAsc() {
        List<T> out = new ArrayList<>(items);
        out.sort(Comparator.comparingDouble(Item::getPrice));
        return out;
    }

    public List<T> sortByPriceDesc() {
        List<T> out = new ArrayList<>(items);
        out.sort(Comparator.comparingDouble(Item::getPrice).reversed());
        return out;
    }
}
