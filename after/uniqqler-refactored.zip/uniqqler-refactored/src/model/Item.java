package model;

/** A sellable product. (Renamed from the original plural "Items".) */
public interface Item {
    String getName();
    double getPrice();
    String getColor();
    void setPrice(double price);
}
