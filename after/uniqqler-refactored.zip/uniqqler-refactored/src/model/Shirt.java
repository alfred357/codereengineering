package model;

public abstract class Shirt implements Item, HasCategory {
    protected String name;
    protected double price;
    protected String color;

    protected Shirt(String name, double price, String color) {
        this.name = name;
        this.price = price;
        this.color = color;
    }

    /**
     * Factory: hides the LongSleeve/ShortSleeve subclasses and removes the
     * if-else-on-string block that used to live in Main.addItemToStore().
     */
    public static Shirt of(Category category, String name, double price, String color) {
        switch (category) {
            case LONG:
                return new LongSleeve(name, price, color);
            case SHORT:
                return new ShortSleeve(name, price, color);
            default:
                throw new IllegalArgumentException("Unsupported category: " + category);
        }
    }

    @Override
    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public String getColor() {
        return color;
    }

    @Override
    public abstract Category category();
}

class LongSleeve extends Shirt {
    LongSleeve(String name, double price, String color) {
        super(name, price, color);
    }

    @Override
    public Category category() {
        return Category.LONG;
    }
}

class ShortSleeve extends Shirt {
    ShortSleeve(String name, double price, String color) {
        super(name, price, color);
    }

    @Override
    public Category category() {
        return Category.SHORT;
    }
}
