package model;

/**
 * Replaces the magic strings "long" / "short" that were duplicated across
 * Main and the Shirt subclasses. Single source of truth for categories.
 */
public enum Category {
    LONG("long"),
    SHORT("short");

    private final String label;

    Category(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    /** Parse user input (case-insensitive) into a Category. */
    public static Category fromLabel(String label) {
        for (Category c : values()) {
            if (c.label.equalsIgnoreCase(label)) {
                return c;
            }
        }
        throw new IllegalArgumentException("Unknown category: " + label);
    }
}
