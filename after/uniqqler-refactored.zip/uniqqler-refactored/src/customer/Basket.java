package customer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import model.Item;

public class Basket {
    private final List<Item> items = new ArrayList<>();

    public void addItem(Item item) {
        items.add(item);
    }

    /** Encapsulate Collection: hand back a read-only view. */
    public List<Item> getItems() {
        return Collections.unmodifiableList(items);
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }
}
