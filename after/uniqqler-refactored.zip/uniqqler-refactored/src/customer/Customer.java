package customer;

import java.util.List;

import model.Item;

public class Customer {
    private final String name;
    private final Basket basket = new Basket();

    public Customer(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    // Hide Delegate: callers no longer write customer.getBasket().addItem(...)
    public void addToBasket(Item item) {
        basket.addItem(item);
    }

    public List<Item> getBasketItems() {
        return basket.getItems();
    }

    public boolean isBasketEmpty() {
        return basket.isEmpty();
    }
}
