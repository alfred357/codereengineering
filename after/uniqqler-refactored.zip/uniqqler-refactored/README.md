# Uniqqler — Versi Refactored

Ini adalah hasil refactoring dari program Uniqqler (aplikasi konsol toko kaos
berbasis Java). Perilaku program tetap sama dengan versi asli; yang berubah
adalah struktur kodenya agar bebas dari code smell.

## Struktur paket

- `model/`  — domain: `Item`, `HasCategory`, `Category` (enum), `Shirt`
  (+ `LongSleeve`, `ShortSleeve`), dan `Store` (container generic)
- `customer/` — `Customer` dan `Basket`
- `ui/`     — `ConsoleView`: satu-satunya tempat I/O (Scanner + System.out)
- `app/`    — `Main` (orkestrasi + login + data awal), `Role`,
  `BrowseController`, `CustomerController`, `AdminController`

## Ringkasan perbaikan

- God Class `Main` dipecah (Extract Class) menjadi view + controller-controller
- Tabel item yang dulu duplikat 3x kini satu method `printItemTable`
- Pengumpulan kategori/warna dipindah ke `Store` (Move Method)
- `customer.getBasket().addItem(...)` -> `customer.addToBasket(...)` (Hide Delegate)
- String `"long"`/`"short"` diganti enum `Category` (Replace Type Code with Enum)
- Angka menu diganti konstanta bernama (Replace Magic Number with Constant)
- `getItems()` mengembalikan list read-only (Encapsulate Collection)
- Rename: `UpdatePriceInStore`->`updatePrice`, `hasCategory`->`HasCategory`,
  `Items`->`Item`
- Dead code dibersihkan; input non-angka tidak lagi membuat program crash

## Cara kompilasi & menjalankan

```bash
cd uniqqler-refactored
javac -d out $(find src -name "*.java")
java -cp out app.Main
```

Saat diminta kredensial, ketik `customer` atau `admin`.
